<div class="container-fluid position-relative p-0">
            <nav class="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0" style="position:absolute">
                    <a href="index.php" class="navbar-brand">
                        <h1 class="m-0 text-uppercase "><i class="fa fa-home me-2"></i>HomeStays</h1>
                    </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
                        <div class="navbar-nav ms-auto py-0">
                            <a href="../index.php" class="nav-item nav-link">Home</a>
                            <a href="about.php" class="nav-item nav-link">About</a>
                            <a href="service.php" class="nav-item nav-link">Services</a>
                            <a href="review.php" class="nav-item nav-link">Reviews</a>
                            <a href="FAQuestion.php" class="nav-item nav-link">FAQ Questions</a>
                            <a href="contact.php" class="nav-item nav-link">Contact</a>
                            <a href="login.php" class="nav-item nav-link">Login</a>
                            <a href="register.php" class="nav-item nav-link">Register</a>
                        </div>
                    </div>
            </nav>
        </div>