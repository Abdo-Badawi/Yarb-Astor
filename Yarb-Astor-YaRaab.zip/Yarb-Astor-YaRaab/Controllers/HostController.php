<?php
require_once 'DBController.php';

class HostController {
    private $db;
    
    public function __construct() {
        $this->db = new DBController();
    }
    
    // Get host by ID
    public function getHostById(int $hostId): ?array {
        $sql = "SELECT * FROM users WHERE user_id = ? AND user_type = 'host'";
        
        $this->db->openConnection();
        $result = $this->db->selectPrepared($sql, "i", [$hostId]);
        $this->db->closeConnection();
        
        return $result ? $result[0] : null;
    }
    
    // Get all hosts
    public function getAllHosts(): array {
        $sql = "SELECT * FROM users WHERE user_type = 'host'";
        
        $this->db->openConnection();
        $result = $this->db->select($sql);
        $this->db->closeConnection();
        
        return $result ?: [];
    }
    
    // Update host profile
    public function updateHostProfile(int $hostId, array $data): bool {
        $sql = "UPDATE users SET 
                first_name = ?, 
                last_name = ?, 
                email = ?, 
                phone_number = ?, 
                date_of_birth = ?, 
                gender = ? 
                WHERE user_id = ? AND user_type = 'host'";
        
        $params = [
            $data['first_name'],
            $data['last_name'],
            $data['email'],
            $data['phone_number'],
            $data['date_of_birth'],
            $data['gender'],
            $hostId
        ];
        
        $this->db->openConnection();
        $result = $this->db->update($sql, "ssssssi", $params);
        $this->db->closeConnection();
        
        return $result;
    }
    
    // Create new host
    public function createHost(array $data): int {
        $sql = "INSERT INTO users (user_type, first_name, last_name, email, password, phone_number, date_of_birth, gender, created_at) 
                VALUES ('host', ?, ?, ?, ?, ?, ?, ?, NOW())";
        
        $params = [
            $data['first_name'],
            $data['last_name'],
            $data['email'],
            password_hash($data['password'], PASSWORD_DEFAULT),
            $data['phone_number'] ?? null,
            $data['date_of_birth'] ?? null,
            $data['gender'] ?? null
        ];
        
        $this->db->openConnection();
        $result = $this->db->insert($sql, "sssssss", $params);
        $insertId = $this->db->getInsertId();
        $this->db->closeConnection();
        
        return $insertId;
    }
    
    // Authenticate host
    public function authenticateHost(string $email, string $password): ?array {
        $sql = "SELECT * FROM users WHERE email = ? AND user_type = 'host'";
        
        $this->db->openConnection();
        $result = $this->db->selectPrepared($sql, "s", [$email]);
        $this->db->closeConnection();
        
        if ($result && password_verify($password, $result[0]['password'])) {
            return $result[0];
        }
        
        return null;
    }
    
    // Delete host
    public function deleteHost(int $hostId): bool {
        $sql = "DELETE FROM users WHERE user_id = ? AND user_type = 'host'";
        
        $this->db->openConnection();
        $result = $this->db->delete($sql, "i", [$hostId]);
        $this->db->closeConnection();
        
        return $result;
    }
    
    // Get hosts by location
    public function getHostsByLocation(string $location): array {
        $sql = "SELECT * FROM users WHERE user_type = 'host' AND location LIKE ?";
        
        $this->db->openConnection();
        $result = $this->db->selectPrepared($sql, "s", ["%$location%"]);
        $this->db->closeConnection();
        
        return $result ?: [];
    }
    
    // Method to get host reviews
    public function getHostReviews($hostId) {
        $sql = "SELECT r.*, u.first_name, u.last_name, u.profile_picture 
                FROM reviews r 
                JOIN users u ON r.reviewer_id = u.user_id 
                WHERE r.host_id = ? 
                ORDER BY r.created_at DESC";
        
        $this->db->openConnection();
        $result = $this->db->selectPrepared($sql, "i", [$hostId]);
        $this->db->closeConnection();
        
        return $result ?: [];
    }
}
?>






